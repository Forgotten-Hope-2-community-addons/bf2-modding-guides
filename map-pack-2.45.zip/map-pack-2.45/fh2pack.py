# -*- coding: iso-8859-15 -*-
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@8:........C@@@
# @@@@@@@@@@@@@@88@@@@@@@@@@@@@@@@@@@@@@88@@@@@@@@@@888@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@O:...........:C@
# @       .@O        O@8         C@@O        o@@@:       cO                   oc       8o   .@@.   @c....:O@@:....:@
# @     .:c8    CO    O8    :o    O8    oO    C@.   :8.   :::.    ..::.     ::Cc    ..:8o    o@:   @o....:8@@:....:@
# @    c@@@O    OO    C8    c@    OO    o8    c@.   :@.   :@@C    O@@@@.   :@@@c    8@@@@@@@@@@@@: @@@@@@@@@O.....:@
# @     ..oO    OO    C8         .@O    o@@@@@@@.   :@.   :@@C    O@@@@.   :@@@c    :C8@@@o O@@ccC @@@@@@@O.......c@
# @       oO    OO    C8         C@O    o.    c8.   :@.   :@@8OOCo8@@@@.   :@@@8@@@@@@O@@@@@@@8C:  @@@@@C.......o@@@
# @    c@@@O    OO    C8    c8    OO    oO    c@.   :@.  o@@@@@@@@@@@@@@@@@@@@@o    8@@@o ..o      @@@C......:C@@@@@
# @    c@@@O    CO    C8    c8    OO    o@.   c@.   :@..o8@@@@@@@@@@@@@@@@Oc@@@c    8@@@o   oo     @C......:O@@@@@@@
# @    c@@@@    ..    88    c8    O@.   .:    c@c    :o@@@@@@@@@@@@@@@@@@@@@@@@Ooc::   Co   o@.    @c....:O@@@@@@@@@
# @    c@@@@@o      o@@8    c@    O@@o    cc  c@@O.  c@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@:  Co   o@O    @c....:O8@@@@@@@@
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@:C@:C:..:C.:.:c.:.@o.............:@
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.:o o.oo o ooCc.oC@c.............:@
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#
# fh2pack.py -- fh2 packing scripts (stripped version)
#  �2006 Joseph Birr-Pixton aka ctz for Forgotten Hope
#  �2010-2012  Michal Borejszo aka Spit for Forgotten Hope

import os, os.path, glob, fnmatch, shutil, zipfile, re
from dependencies import dependencies as dep_dict

COM_EOF = '$fh2_eof'
COM_KITGEOMSUBFOLDER = '$fh2_kitgeomsubfolder'

inclusions = {
    'client': ('*.font', '*.dif', '*.difb', '*.fx', '*.mfx', '*.dfx', '*.mesh',
               '*.bundledmesh', '*.staticmesh', '*.skinnedmesh', '*.treemesh',
               '*.mp3', '*.tga', '*.gif', '*.jpg', '*.wav', '*.avi', '*.bik',
               '*.dat', '*.ogg', '*.occ', '*.ani', '*.swf', '*.dds', '*.png',
               '*.tai', '*.tac', '*.baf', '*.inc',
               'lightmaps\objects\lightmapatlas.tai', 'terraindata.raw',
               'undergrowth.cfg', 'undergrowth.raw'),
    'server': ('*',),
}

exclusions = {
    'client': ('external/flashmenu/cursor/*.ani', 'external/flashmenu/cursor/*.cur',
               '*.bak', 'editor/*', 'info/*', '*.svn/*', '.svn/*', '*/.svn/*',
               '*.samples', '*.samp_01', '*.samp_02', '*.samp_03', '*.samp_04', '*.max', '*.baf', '*.psd',
               '*.db',),
    'server': ('*.font', '*.dif', '*.difb', '*.fx', '*.dfx', '*.mesh',
               '*.bundledmesh', '*.staticmesh', '*.skinnedmesh', '*.treemesh',
               '*.mp3', '*.dds', '*.tga', '*.gif', '*.jpg', '*.wav', '*.avi',
               '*.bik', '*.dat', '*.png', '*.ogg', '*.occ', '*.ani', '*.swf',
               '*.samples', '*.samp_01', '*.samp_02', '*.samp_03', '*.samp_04',
               '*.bak', 'terraindata.raw', 'undergrowth.cfg', '*.tac', '*.py',
               'undergrowth.raw', 'lightmaps/*', '*.db', '*.bik', '*.dat',
               '*.psd', '*.nfo', '*.zip', '*.rar', 'info/*', 'gpu_*.*',
               'external/flashmenu/cursor/*', '*.svn/*', '.svn/*', '*/.svn/*', '*.max'),
}
        
def wildcardedby(path, wildcards):
    for w in wildcards:
        if fnmatch.fnmatch(path.lower(), w.lower()):
            return True
    return False

def include(p, what, target):
    inc = inclusions[target.lower()]
    exc = exclusions[target.lower()]
    shouldinc = False
    if wildcardedby(p, inc):
        shouldinc = True
    if wildcardedby(p, exc):
        shouldinc = False
        
    return shouldinc
    
def pack_maps(map_folders_path = '../Levels/*/'):
    map_folders = glob.glob(map_folders_path)
    files_ = []
    
    if os.name == 'posix':
        for f in map_folders:
            svn = os.path.join(f, '.svn')
            if not os.path.isdir(svn):
                print 'Removing old unversioned folder:', f
                shutil.rmtree(f)

    print 'building map file list...'
    for m in map_folders:
        if '.svn' in m: continue
        if not (os.path.isfile(os.path.join(m, 'server.zip')) and os.path.isfile(os.path.join(m, 'client.zip'))):
            needs_repack = True
        else:
            needs_repack = False
        if not needs_repack:
            pack_time = min(os.stat(os.path.join(m, 'server.zip')).st_mtime, os.stat(os.path.join(m, 'client.zip')).st_mtime)
        else:
            pack_time = 0
        ignore_dirs = []
        f = []
        for root, dirs, files in os.walk(m):
            ignore = False
            if '.svn' in root: continue
            if 'editor' in root.lower(): continue
            if 'info' in root.lower(): continue
            if 'ignore.txt' in files and map_folders_path == '../Levels/*/':
                ignore_dirs.append(root)
            for id in ignore_dirs:
                if id in root: ignore = True
            if ignore: continue
            for file in files:
                if file in ('server.zip', 'client.zip'):
                    continue
                if not needs_repack and os.stat(os.path.join(root, file)).st_mtime > pack_time:
                    needs_repack = True
                if file == 'tmp.con':
                    file = process_tmp(os.path.join(root, file))
                if file == 'sky.con':
                    file = process_sky(os.path.join(root, file))
                if os.path.join(m.lower(), 'lightmaps') in root.lower():
                    if not (file.lower().endswith('.dds') or file.lower().endswith('.tai')): continue
                    if os.path.join(m.lower(), 'lightmaps', 'objects') in root.lower():
                        if not file.lower().startswith('lightmapatlas'): continue
                f.append(os.path.join(root, file))
        if f:
            files_.append((m, f, needs_repack))
    
    def cleanup():
        tmp_files = ['tmp.con_release', 'sky.con_release']
        for tmp in [os.path.join(map, x) for x in tmp_files]:
            if os.path.isfile(tmp):
                os.remove(tmp)
    
    for map, files, needs_repack in files_:
        if not files: continue
        if not needs_repack and os.name == 'posix': # We still repack on Windows, to avoid confusion in some cases.
            print map, 'does not need repack'
            cleanup()
            continue
        print 'packing map', map,
        client_z = zipfile.ZipFile(os.path.join(map, 'client.zip'), 'w', zipfile.ZIP_DEFLATED)
        server_z = zipfile.ZipFile(os.path.join(map, 'server.zip'), 'w', zipfile.ZIP_DEFLATED)
        
        for f in files:
            if include(os.path.basename(f), None, 'client'):
                client_z.write(f, f.replace(map, '').replace('.con_release', '.con'))
            if include(os.path.basename(f), None, 'server'):
                server_z.write(f, f.replace(map, '').replace('.con_release', '.con'))
                
        client_z.close()
        server_z.close()
        
        cleanup()
        
        print 'done'

class Set(set):
    # Set accepting only logic-1 values.
    def add(self, what):
        if what:
            set.add(self, what)

def process_sky(path):
    src = open(path, 'r')
    outpath = path.replace('sky.con', 'sky.con_release')
    out = open(outpath, 'w')
    mappath = os.path.split(path)[0]
    size = get_map_size(mappath)
    for line in src.readlines():
        if line.lower().startswith('hemimapmanager.setbasehemimap'):
            bits = line.split()
            bits[3] = '%d.000000' % size
            line = ' '.join(bits) + '\n'
        out.write(line)
    src.close()
    out.close()
    return os.path.split(outpath)[1]
            
def get_map_size(mappath):
    hdp = os.path.join(mappath, 'Heightdata.con')
    assert os.path.isfile(hdp), 'fh2pack.py: get_map_size can\'t find file %s' % hdp
    size = None
    hd = open(hdp, 'r')
    for line in hd.readlines():
        if line.lower().startswith('heightmapcluster.setheightmapsize'):
            size = int(line.split()[1])
    hd.close()
    assert size is not None
    return size
            
def get_subfolders(line, subfolders):
    for word in line.split():
        if word.startswith(COM_KITGEOMSUBFOLDER):
            comm, data = word.split('=')
            for type in data.split(','):
                kitset, subfolder = type.split(':')
                subfolders[kitset.lower()] = subfolder + '/'
    return subfolders
    
def process_tmp(path):
    
    class tmp(object):
        def __init__(self, out):
            self.out = out
        
        def write(self, what):
            if what.lower().startswith('run'):
                if what.lower() not in [x.lower().replace('\n', '') for x in _lines]:
                    self.out.write(what)
                else:
                    self.out.write('rem ' + what)
            else:
                self.out.write(what)
                
        def close(self):
            self.out.close()
    
    subfolders = {}
    src = open(path, 'r')
    outpath = path.replace('tmp.con', 'tmp.con_release')
    out = open(outpath, 'w')
    # Implementing COM_EOF here:
    _lines = []
    src.seek(0)
    last = None
    for line in src:
        subfolders = get_subfolders(line, subfolders)
        if COM_EOF in line.split():
            break
        if '\n' not in line:
            line += '\n\n'
        out.write(line)
        _lines.append(line)
        last = line
    if last != '\n':
        out.write('\n')
    src.close()
    mappath = os.path.split(path)[0]
    kits = Set()
    kitsets = Set()
    initconpath = os.path.join(mappath, 'Init.con')
    for k, ks in get_kits(initconpath):
        kits.add(k.lower())
        kitsets.add(ks.lower())
    update_templates(initconpath)
    # for k, ks in get_kits(os.path.join(mappath, 'StaticObjects.con')):
        # kits.add(k.lower())
        # kitsets.add(ks.lower())
    for x in glob.glob(os.path.join(mappath, 'GameModes/*/*/GamePlayObjects.con')):
        for k, ks in get_kits(x):
            kits.add(k.lower())
            kitsets.add(ks.lower())
        update_templates(x)
    out = tmp(out)
    print >>out, 'rem Everything below this line will be ignored by packing scripts! $fh2_eof'
    print >>out, ''
    print >>out, 'rem ***  KIT LOADERS  ***'
    print >>out, 'rem *** autogenerated ***'
    print >>out, ''
    for k in kits:
        kitset = k.replace('spawnable/', '').split('_')[0]
        if k.startswith('spawnable/'):
            folder = 'spawnable'
        else:
            folder = kitset
        k = k.replace('spawnable/', '')
        print >>out, 'run ../../objects/kits/%(folder)s/%(k)s.inc' % locals()
    print >>out, ''
    print >>out, 'rem *** KITSETS ***'
    for ks in kitsets:
        if len(ks) == 2:
            folder = ks
        else:
            folder = ks[:2]
        subfolder = subfolders.get(folder, '')
        print >>out, 'run ../../objects/kits/%(folder)s/%(subfolder)s%(ks)s_kits.inc' % locals()
    print >>out, ''
    # Kit spawners should go as last ones (after kits' and geoms' templates are loaded into memory)
    print >>out, 'rem *** KIT SPAWNERS ***'
    for ks in kitsets:
        if len(ks) == 2:
            folder = ks
        else:
            folder = ks[:2]
        print >>out, 'run ../../objects/kits/%(folder)s/%(ks)s_kits_spawner.inc' % locals()
    print >>out, ''
    global map_templates
    process_dependencies(map_templates) # First level dependencies
    while True: # deep level dependencies
        result = process_dependencies([d.template for d in dependencies])
        if result == 0: break
    if dependencies:
        print >>out, 'rem *** CUSTOM DEPENDENCIES **'
        print >>out, ''
    for d in dependencies:
        template = d.template
        print >>out, 'rem', d.template
        print >>out, 'rem Pulled in by', ', '.join(d.parents)
        print >>out, """ObjectTemplate.create ObjectSpawner %(template)s_spawner_autogenerated
ObjectTemplate.activeSafe ObjectSpawner %(template)s_spawner_autogenerated
ObjectTemplate.isNotSaveable 1
ObjectTemplate.hasMobilePhysics 0
ObjectTemplate.setObjectTemplate 0 %(template)s
""" % locals()
    out.close()
    return os.path.split(outpath)[1]
    
class dependency(object):
    def __init__(self):
        self.template = None
        self.parents = set()

map_templates = set()
dependencies = []

def process_dependencies(list):
    global dependencies
    newfound = 0
    for t in list:
        deps = dep_dict.get(t, None)
        if not deps: continue
        # This template requires to load another templates...
        for dep in deps:
            dep = dep.lower()
            # First we check if this is loaded by something another
            found = False
            for d in dependencies:
                if d.template == dep:
                    found = True
                    # Something already loads that as dependency, so we just add our template to parents list
                    d.parents.add(t)
                    break
            if found: continue # next dependency
            # if it is not loaded yet:
            d = dependency()
            d.parents.add(t)
            d.template = dep
            dependencies.append(d)
            newfound += 1
    return newfound

def update_templates(path):
    assert os.path.isfile(path)
    global map_templates
    f = open(path, 'r')
    for l in f.readlines():
        l = l.lower()
        if l.startswith('objecttemplate.setobjecttemplate'):
            template = l.split()[2]
            map_templates.add(template)
        elif l.startswith('gamelogic.setkit'):
            bits = l.split()
            map_templates.add(bits[3].replace('"', ''))
            map_templates.add(bits[4].replace('"', ''))
    f.close()
    
def get_kits(path):
    assert os.path.isfile(path)
    f = open(path, 'r')
    for l in f.readlines():
        if l.lower().startswith('gamelogic.setkit'):
            kit = l.split()[3].replace('"', '')
            kitset = l.split()[4].replace('"', '').split('_')[0]
            yield kit, kitset
        elif re.match(r'objecttemplate.setobjecttemplate \d [a-z][a-z]_pickup.+', l.lower()):
            p = l.split()[2]
            yield 'spawnable/' + p, ''
    f.close()
