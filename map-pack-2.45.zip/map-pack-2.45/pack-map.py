import os, glob, sys
from fh2pack import pack_maps

def go(mapname = None):
    if mapname is None:
        mapname = raw_input('Mapname to pack? ')
    if mapname.lower() in ('exit', 'quit', 'bye'):
        sys.exit()
    if not os.path.exists(os.path.join('Levels', mapname)) or mapname.strip() == '':
        print 'Can\'t find that map. Try again.'
        go()
    print ''
    pack_maps('Levels/%s/' % mapname)

if __name__ == '__main__':
    if len(sys.argv) == 1:
        go()
    else:
        go(sys.argv[1])
    
