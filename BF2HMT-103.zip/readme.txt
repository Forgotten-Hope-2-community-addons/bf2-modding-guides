>> Lorne's Online Portfolio
   www.lorneswork.com
   � Lorne Douglas McIntosh
   ---------------------------
>> Email: lorne at lorneswork.com


>>    Project:
--------------------------------
BF2 HeightMap Tool (BF2HMT) v1.03


>>    Description:
--------------------------------
A tool that automates the import of heightmaps into Battlefield 2.


>>    System Requirements:
--------------------------------
In order to run BF2HMT, you must have the Java Virtual Machine installed on your computer. A copy can be downloaded from: http://java.com/en/download/index.jsp


>>    Installation:
--------------------------------
No installation is necessary. Simply unzip the .zip file to a location on your local hard-drive. For example: C:/Program Files/BF2HMT/


>>    Instructions:
--------------------------------
To run BF2HMT, double click BF2HMT.bat and the tool should launch automatically.

Double-check that the Game Directory on the right-hand side is correct. Next, select your mod, and then the level you wish to import the heightmap into. Please note that only unpackaged levels will work - the standard "vanilla" levels come zipped up by default and won't work with this tool until you unzip them.

Click the "Open..." button to browse for the heightmap image to import. A wide variety of image types are supported (.raw files are not, currently). Loading the image may take up to 20 seconds. At this point you can take a look at the main window to see how your level will look. The center square will become the "primary" heightmap (the area where all the action happens), and the rest will become "secondary" heightmaps (the surrounding scenery).

When you are ready, click "Export to level...". A dialog box will check that you know what you're doing. Click 'yes', and the export process will begin. It should only take a few seconds.


>>    Troubleshooting:
--------------------------------
When starting the program, if you receive the error message: "java is not recognized...", check to ensure that the Java Virtual Machine is installed (see above), and that Java's \bin directory is in your Windows "Path" System Variable.

Please report any bugs to:
lorne@lorneswork.com


>>    Legal:
--------------------------------
To the maximum extent permitted by law, this Software is distributed "AS IS" and WITHOUT ANY WARRANTY INCLUDING BUT NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR PARTICULAR PURPOSE, or NON-INFRINGEMENT. IN NO EVENT WILL THE AUTHOR, LORNE MCINTOSH, BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND ARISING FROM OR RELATED TO THE USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR ITS DERIVATIVES.


>>    Notes:
--------------------------------
If you use this tool to create a level, please let me know. I'd love to play it :)


>>    Change-log:
--------------------------------

v1.03 (2007-03-31)
==================
 - Fixed: Output map rotated by 180 degrees
 - Fixed: Reduced filesize
 - Added: Support for JRE version 1.4


v1.02 (2006-07-22)
==================
 - Fixed: missing libraries


v1.01 (2006-07-18)
==================
 - Fixed: won't run without BF2 registry entry
 - Fixed: missing library, jai_codec.jar


v1.00 (2006-06-18)
==================
 - First public release