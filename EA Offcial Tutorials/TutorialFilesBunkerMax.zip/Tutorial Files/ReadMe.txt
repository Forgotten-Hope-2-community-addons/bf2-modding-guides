To install:
1. Copy the folder "Objects" to your "RawData" folder. 

NOte: If you already have an "Objects" folder in your RawData folder, please copy whatever files and folders are necessary to create the following path:
C:Program Files\EA Games\Battlefield 2\bf2editor\RawData\Objects\StaticObjects\_MyBase01\My_Bunker.
The folder "_MyBase01" should also contain the folder "textures".

The point here is to create the same exact directory structure from "Objects" on as that of your mod. This way when you import something into the editor, the resulting object will get placed in the correct directory.


2. Make sure that you have created the mod "MyMod" through the editor. If not, do so following the steps in "Battlefield 2 Modding Tutorial 3 - Custom Mod Set-Up" before proceeding.

3. Copy the folder "textures" to the following path:
C:Program Files\EA Games\Battlefield 2\mods\MyMod\Objects\StaticObjects\_MyBase01.

Note: Create any folders necessary to create the above path. The point here is to create the path in your mod to where the object will be placed. We are copying the textures to their final destination now because the Max exporter does not automatically move them.


You are now ready to follow along with "Battlefield 2 Modding Tutorial 4 - Building The Bunker".