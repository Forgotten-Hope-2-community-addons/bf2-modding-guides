04:00 GMT 01.02.2006
====================
BF2Ecomap version 0.21 available.

Fixes: Division by zero error when loading a black (empty) heighfield. Thanks to CheetahShrk for reporting the bug.

03:00 GMT 01.02.2006
====================
BF2Ecomap version 0.2 available.

After a tough fight with my C++ compilers/IDE, i have managed to pull out a new release. 

Unfortunately, 90% of the time spent developing this program, was lost in effort to make my C++ IDEs work. For that reason, for now the fancy XP style interface is gone. 

Improvements:
	- At least 30% faster rendering
	- Much better quality of the final texture
	- Memory usage has been decreased by 50% for the final render
	- No more need to enter manually the scale. The program imports the scale settings from the BF2 level
	- The scale is now displayed in the main window.
	- Added support for the surround terrain
	- Bug fixes ...
	
Don't forget to post any bug or request in the forum: http://www.leetdreams.com/forum/ 	

04:00 GMT 24.01.2006
====================

BF2Ecomap version 0.11 available.
This version fixes a major bug: when splitting the final textures, row and column were exchanged.


04:00 GMT 23.01.2006
====================

BF2Ecomap version 0.1 available

This is the first public version. It's far from being final. Many bugs to be corrected, many new features to be added.

Feel free to discuss, report bugs or request features at BF2Ecomap forum (no registration needed): http://www.leetdreams.com/forum/

DISCLAIMER
==========

By using this program you ACCEPT the following disclaimer.

THIS PROGRAM  COMES WITH  ABSOLUTELY NO WARRANTY OF ANY KIND.
BY ACCEPTING THIS DISCLAIMER, YOU USE THIS PROGRAM AT YOUR OWN RISK.
THE AUTHOR CAN NOT BE HELD RESPONSIBLE FOR ANY DIRECT OR INDIRECT DAMAGE DONE BY THIS PROGRAM. 
IF YOU DO NOT ACCEPT THIS DISCLAIMER, OR YOU DO NOT UNDERSTAND IT, DO NOT START THE PROGRAM

Info
====
This program automates the texturing of BF2 maps. You can control the texturing by set of rules that take into account the geometry of the terrain. That way you can have snow on top of the mountains and rocks on sloppy terrain ...

Installation
============
Unzip all the files in Folder of your choice, then start the bf2ecomap.exe

License
=====
This program is FREE. You may use it and and distribute it freely ;however, you may not sell it.For more details read the license.txt file included with the program. 

How to (leet short version)
===========================
BF2Ecomap Materials = BF2Editor Layers

1. Create your map in the BF2Editor.
2. Create/paint or import a heightfield.
3. Assign Detail textures the layers (as many as you want)
4. Save the map
5. Open BF2Ecomap
6. Create a new project: choose a BF2 Mod, then browse to the folder containing the existing BF2 Editor map
7. To add/edit a Color/Detail Material, click the corresponding Material Editor button
8. Every Material must have a Name, Rule and Texture (for now the detail material does not have one).
9. To add a new rule press the Rule Editor button
19. The Rules instruct the program where to apply a selected texture. It takes into account the Height and slope of the terrain.
11. Once the Materials is created, Preview and adjust.
12. Save your project
13. When you are ready, you can Render the final texture. Check "Save sliced", to save the rendered texture for use in the BF2 editor.
14. Be patient, it make take a few minutes to render big maps. Bigger the map, slower. More Materials, slower.
15. Go to the BF2Ecomap forum and complain about any bug or ...

Known issues
=============
The materials in BF2Ecomap are not imported from the BF2Editor project.
The materials in BF2Ecomap are not saved into the BF2Editor project, but only into the BF2Ecomap project.
You must click Apply button for any modification to a rule or material to be applied.
Be careful, you can add more than 6 detail materials. DO NOT ADD more than 6 or the rendering will fail (BF2 only supports 6). 
You can't choose a texture for the detail material.
While rendering, the application is unresponsive.
It's relatively slow.

All these issues will be addressed.

Please report any other bugs you find in the forum: http://www.leetdreams.com/forum/ 

To come
=======
Depends of the interest of the bf2 mappers community.

Contact
=======
BF2Ecomap home: http://www.leetdreams.com/bf2ecomap
BF2Ecomap forum: http://www.leetdreams.com/forum/