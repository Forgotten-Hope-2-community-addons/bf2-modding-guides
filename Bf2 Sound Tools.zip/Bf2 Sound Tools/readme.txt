getogginfo.bat:
Drag & Drop an ogg onto it to extract bitrate, serialnumber and so on.

make19khzoggwithserial.bat: 
creates a low bitrate ogg from a 8 khz WAV and asks for a serialnumber (enter it in decimal notation) 

make56khzoggwithserial.bat: 
same for higher quality files. Use a 22khz WAV file when converting. 

Before using the package, edit the batch files for the location of your ogg tools.  